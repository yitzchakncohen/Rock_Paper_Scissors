using RockPaperScissors.Grids;
using RockPaperScissors.Units;

public class EnemyAIAction
{
    public GridObject gridObject;
    public UnitAction unitAction;
    public float actionValue;
}
