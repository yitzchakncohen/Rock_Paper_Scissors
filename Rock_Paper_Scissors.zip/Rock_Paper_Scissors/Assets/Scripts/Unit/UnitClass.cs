using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace RockPaperScissors.Units
{
    public enum UnitClass
    {
        Rock,
        Paper,
        Scissors,
        PillowFort,
        PillowOutpost
    }
}
