namespace RockPaperScissors.Grids
{
    public enum GridHighlightType
    {
        Movement,
        Attack,
        PlaceObject,
    }    
}
